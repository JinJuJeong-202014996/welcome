import java.util.*;

class Item {
	String id;
	String name;
	int price;

	void read(Scanner sc) {
		id = sc.next();
		if (id.equals("0")) {
			return;
		}
		name = sc.next();
		price = sc.nextInt();
	}

	void print() {
		if (name.length() < 9) {
			System.out.println("[" + id + "] " + name + "\t\t" + price + "��");
		} else
			System.out.println("[" + id + "] " + name + "\t" + price + "��");
	}
}

public class Management {
	Scanner scan = new Scanner(System.in);
	ArrayList<Item> itemList = new ArrayList<>();

	public void run() {
		readAll();
		printAll();
	}

	public void readAll() {
		while (true) {
			Item item = null;
			item = new Item();
			item.read(scan);
			if (!item.id.equals("0")) {
				itemList.add(item);
			} else
				break;
		}
	}

	public void printAll() {
		for (Item item : itemList) {
			System.out.printf("%2d) ", itemList.indexOf(item) + 1);
			item.print();
		}
	}

	public static void main(String[] args) {
		Management manage = new Management();
		manage.run();
	}
}
